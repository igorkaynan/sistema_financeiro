<nav>
    <div>
        <strong>Sistema de Loja</strong>
    </div>
    <div>
        <a href="dashboard.php">Dashboard</a>
        <a href="produtos.php">Produtos</a>
        <a href="estoque.php">Estoque</a>
        <a href="vendas.php">Vendas</a>
        <a href="entrada_saida.php">Entrada e Saída</a>
        <a href="fornecedores.php">Fornecedores</a>
        <a href="relatorios.php">Relatórios</a>
        <a href="logout.php" style="color: red;">Logout</a>
    </div>
</nav>
